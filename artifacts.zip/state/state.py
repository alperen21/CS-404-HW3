class State:
    def __init__(self, to_move) -> None:
        self.to_move = to_move